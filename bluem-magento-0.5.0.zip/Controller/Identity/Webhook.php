<?php

namespace Bluem\Integration\Controller\Identity;

require_once __DIR__ . '/../BluemWebhookAction.php';

use Bluem\Integration\Controller\BluemWebhookAction;

class Webhook extends BluemWebhookAction
{

}
